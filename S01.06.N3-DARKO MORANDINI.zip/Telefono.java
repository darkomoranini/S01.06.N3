
public interface Telefono {

	 void llamar();
}
