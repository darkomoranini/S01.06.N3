
public class Generic {

	<T extends Telefono> void metodoGenericoTelefono(T telefono) {
        telefono.llamar();
    }

    <T extends Smartphone> void metodoGenericoSmartphone(T smartphone) {
        smartphone.hacerFoto();
    }
}
