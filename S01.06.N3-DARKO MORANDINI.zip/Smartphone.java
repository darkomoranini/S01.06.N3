
public class Smartphone implements Telefono{

	@Override
	public void llamar() {
		 System.out.println("Estás llamando");
	}
	
	public void hacerFoto() {
		System.out.println("Estás usando la cámara");
	}
}
