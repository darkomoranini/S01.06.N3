
public class UsoClase {

	public static void main(String[] args) {
        Smartphone smartphone = new Smartphone();
        Generic generica = new Generic();
        generica.metodoGenericoTelefono(smartphone);
        generica.metodoGenericoSmartphone(smartphone);
    }
}
